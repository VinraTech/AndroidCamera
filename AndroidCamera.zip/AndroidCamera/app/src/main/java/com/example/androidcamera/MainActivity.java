package com.example.androidcamera;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import android.widget.Toast;

import com.example.androidcamera.fragments.AddDevice;
import com.example.androidcamera.fragments.VideoViews;
import com.example.androidcamera.fragments.chooseStorage;
import com.example.androidcamera.fragments.deviceManager;
import com.example.androidcamera.fragments.livepreview;

public class MainActivity extends AppCompatActivity {
    WebView webView,webView2;
    TextView livepreview,addDevice,deviceMgr,chooseDevice;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        livepreview=findViewById(R.id.livePreview);
        addDevice=findViewById(R.id.AddDevice);
        deviceMgr=findViewById(R.id.deviceManager);
        chooseDevice=findViewById(R.id.chooseStorage);
        chooseDevice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSupportFragmentManager().beginTransaction().replace(R.id.mainframe,new chooseStorage()).commit();
                chooseDevice.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                chooseDevice.setTextColor(getResources().getColor(R.color.colorPrimaryDark));
                deviceMgr.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));
                deviceMgr.setTextColor(getResources().getColor(R.color.colorPrimary));
                livepreview.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));
                livepreview.setTextColor(getResources().getColor(R.color.colorPrimary));
                addDevice.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));
                addDevice.setTextColor(getResources().getColor(R.color.colorPrimary));

            }
        });
        deviceMgr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSupportFragmentManager().beginTransaction().replace(R.id.mainframe,new deviceManager()).commit();
                deviceMgr.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                deviceMgr.setTextColor(getResources().getColor(R.color.colorPrimaryDark));
                livepreview.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));
                livepreview.setTextColor(getResources().getColor(R.color.colorPrimary));
                addDevice.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));
                addDevice.setTextColor(getResources().getColor(R.color.colorPrimary));
                chooseDevice.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));
                chooseDevice.setTextColor(getResources().getColor(R.color.colorPrimary));

            }
        });
        livepreview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSupportFragmentManager().beginTransaction().replace(R.id.mainframe,new livepreview()).commit();
                Toast.makeText(MainActivity.this, "Viewing Live Previews", Toast.LENGTH_SHORT).show();

                livepreview.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                livepreview.setTextColor(getResources().getColor(R.color.colorPrimaryDark));
                addDevice.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));
                addDevice.setTextColor(getResources().getColor(R.color.colorPrimary));
                deviceMgr.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));
                deviceMgr.setTextColor(getResources().getColor(R.color.colorPrimary));
                chooseDevice.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));
                chooseDevice.setTextColor(getResources().getColor(R.color.colorPrimary));
            }
        });
        addDevice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSupportFragmentManager().beginTransaction().replace(R.id.mainframe,new AddDevice()).commit();
                Toast.makeText(MainActivity.this, "Adding A Device", Toast.LENGTH_SHORT).show();
                  addDevice.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                addDevice.setTextColor(getResources().getColor(R.color.colorPrimaryDark));
                livepreview.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));
                livepreview.setTextColor(getResources().getColor(R.color.colorPrimary));
                deviceMgr.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));
                deviceMgr.setTextColor(getResources().getColor(R.color.colorPrimary));
                chooseDevice.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));
                chooseDevice.setTextColor(getResources().getColor(R.color.colorPrimary));

            }
        });
        /*
        webView = findViewById(R.id.webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setBuiltInZoomControls(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.setSoundEffectsEnabled(true);

        webView.setWebViewClient(new WebViewClient());
        if (Build.VERSION.SDK_INT >= 19) {
            webView.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
        }
        webView.loadUrl("http://162.245.149.145/");

        webView2 = findViewById(R.id.webview2);
        webView2.getSettings().setJavaScriptEnabled(true);
        webView2.getSettings().setAllowFileAccess(true);
        webView2.getSettings().setBuiltInZoomControls(true);
        webView2.setSoundEffectsEnabled(true);

        webView2.setWebViewClient(new WebViewClient());
        webView2.loadUrl("http://91.133.85.170:8090");*/
        getSupportFragmentManager().beginTransaction().replace(R.id.mainframe,new livepreview()).commit();
        livepreview.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
        livepreview.setTextColor(getResources().getColor(R.color.colorPrimaryDark));


    }
}